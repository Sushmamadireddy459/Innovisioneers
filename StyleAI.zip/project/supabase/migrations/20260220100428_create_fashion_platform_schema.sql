/*
  # Fashion Platform Database Schema

  ## Overview
  Creates the complete database schema for the AI-powered fashion recommendation platform.

  ## New Tables

  ### 1. user_profiles
  Stores user fashion preferences and profile information
  - `id` (uuid, primary key) - Unique user identifier
  - `email` (text) - User email address
  - `style_preference` (text) - Preferred fashion style (casual, formal, streetwear, etc.)
  - `favorite_colors` (text[]) - Array of favorite colors
  - `body_type` (text) - Body type for personalized recommendations
  - `budget_range` (text) - Budget preference (budget, mid-range, luxury)
  - `occasions` (text[]) - Types of occasions they dress for
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. saved_outfits
  Stores user's saved outfit recommendations
  - `id` (uuid, primary key) - Unique outfit identifier
  - `user_id` (uuid) - Reference to user_profiles
  - `outfit_name` (text) - Name/title of the outfit
  - `description` (text) - AI-generated outfit description
  - `items` (jsonb) - Array of outfit items with details
  - `occasion` (text) - Suitable occasion for the outfit
  - `season` (text) - Suitable season
  - `style_tags` (text[]) - Style tags for categorization
  - `created_at` (timestamptz) - Creation timestamp

  ### 3. fashion_trends
  Stores curated fashion trend information
  - `id` (uuid, primary key) - Unique trend identifier
  - `trend_name` (text) - Name of the trend
  - `description` (text) - Detailed trend description
  - `category` (text) - Trend category (colors, patterns, styles, etc.)
  - `season` (text) - Relevant season
  - `popularity_score` (integer) - Trend popularity (1-100)
  - `image_url` (text) - Optional trend image URL
  - `created_at` (timestamptz) - Creation timestamp

  ## Security
  - Enable Row Level Security on all tables
  - Users can only access their own profile and saved outfits
  - Fashion trends are publicly readable
*/

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  style_preference text DEFAULT 'casual',
  favorite_colors text[] DEFAULT '{}',
  body_type text DEFAULT 'not_specified',
  budget_range text DEFAULT 'mid-range',
  occasions text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create saved_outfits table
CREATE TABLE IF NOT EXISTS saved_outfits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  outfit_name text NOT NULL,
  description text NOT NULL,
  items jsonb DEFAULT '[]',
  occasion text NOT NULL,
  season text NOT NULL,
  style_tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create fashion_trends table
CREATE TABLE IF NOT EXISTS fashion_trends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trend_name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  season text NOT NULL,
  popularity_score integer DEFAULT 50,
  image_url text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_outfits ENABLE ROW LEVEL SECURITY;
ALTER TABLE fashion_trends ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_profiles
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- RLS Policies for saved_outfits
CREATE POLICY "Users can view own saved outfits"
  ON saved_outfits FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own saved outfits"
  ON saved_outfits FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own saved outfits"
  ON saved_outfits FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for fashion_trends (publicly readable)
CREATE POLICY "Anyone can view fashion trends"
  ON fashion_trends FOR SELECT
  TO anon, authenticated
  USING (true);

-- Insert sample fashion trends
INSERT INTO fashion_trends (trend_name, description, category, season, popularity_score) VALUES
  ('Dopamine Dressing', 'Bold, bright colors and joyful patterns that boost mood and energy. Think vibrant yellows, hot pinks, and electric blues.', 'colors', 'spring', 95),
  ('Quiet Luxury', 'Understated elegance with high-quality fabrics, neutral tones, and timeless silhouettes. Less logos, more sophistication.', 'style', 'all-seasons', 88),
  ('Oversized Blazers', 'Structured yet relaxed blazers in neutral tones, perfect for both professional and casual settings.', 'outerwear', 'fall', 82),
  ('Cargo Everything', 'Functional fashion with cargo pants, skirts, and even dresses featuring multiple pockets and utility details.', 'bottoms', 'all-seasons', 76),
  ('Metallics', 'Silver, gold, and bronze accents adding futuristic glamour to everyday outfits.', 'materials', 'winter', 79),
  ('Maxi Skirts', 'Flowing, ankle-length skirts in various prints and solid colors, offering comfort and elegance.', 'bottoms', 'summer', 85),
  ('Monochrome Sets', 'Matching top and bottom sets in single colors for effortless, coordinated looks.', 'style', 'all-seasons', 90),
  ('Sustainable Fashion', 'Eco-friendly materials, vintage pieces, and ethical brands prioritizing environmental responsibility.', 'lifestyle', 'all-seasons', 92);
