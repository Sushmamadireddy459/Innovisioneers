import { useState } from 'react';
import { Sparkles, Save, RefreshCw, Sun, Cloud, Snowflake, Flower2 } from 'lucide-react';

interface OutfitGeneratorProps {
  onSaveOutfit: (outfit: GeneratedOutfit) => void;
}

interface GeneratedOutfit {
  outfit_name: string;
  description: string;
  items: Array<{ type: string; description: string; color: string }>;
  occasion: string;
  season: string;
  style_tags: string[];
}

export default function OutfitGenerator({ onSaveOutfit }: OutfitGeneratorProps) {
  const [occasion, setOccasion] = useState('casual');
  const [season, setSeason] = useState('spring');
  const [style, setStyle] = useState('modern');
  const [generatedOutfit, setGeneratedOutfit] = useState<GeneratedOutfit | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const occasions = [
    { value: 'casual', label: 'Casual Day Out' },
    { value: 'work', label: 'Professional Work' },
    { value: 'date', label: 'Date Night' },
    { value: 'party', label: 'Party/Event' },
    { value: 'sport', label: 'Athletic/Sport' },
    { value: 'formal', label: 'Formal Event' },
  ];

  const seasons = [
    { value: 'spring', label: 'Spring', icon: Flower2 },
    { value: 'summer', label: 'Summer', icon: Sun },
    { value: 'fall', label: 'Fall', icon: Cloud },
    { value: 'winter', label: 'Winter', icon: Snowflake },
  ];

  const styles = [
    { value: 'modern', label: 'Modern Chic' },
    { value: 'classic', label: 'Timeless Classic' },
    { value: 'streetwear', label: 'Urban Streetwear' },
    { value: 'bohemian', label: 'Bohemian Free' },
    { value: 'minimalist', label: 'Minimalist Clean' },
    { value: 'preppy', label: 'Preppy Smart' },
  ];

  const generateOutfit = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const outfits: Record<string, GeneratedOutfit> = {
        'casual-spring-modern': {
          outfit_name: 'Spring Breeze Casual',
          description: 'A fresh and contemporary look perfect for a relaxed spring day. This outfit combines comfort with style, featuring soft pastels and breathable fabrics.',
          items: [
            { type: 'Top', description: 'Lightweight linen button-up shirt', color: 'Soft Blue' },
            { type: 'Bottom', description: 'High-waisted white denim jeans', color: 'White' },
            { type: 'Shoes', description: 'White leather sneakers', color: 'White' },
            { type: 'Accessory', description: 'Woven crossbody bag', color: 'Tan' },
          ],
          occasion,
          season,
          style_tags: ['casual', 'modern', 'spring', 'comfortable'],
        },
        'work-fall-classic': {
          outfit_name: 'Autumn Professional',
          description: 'A sophisticated ensemble that exudes confidence and professionalism. Warm earth tones and structured pieces create a polished appearance.',
          items: [
            { type: 'Top', description: 'Silk cream blouse with bow detail', color: 'Cream' },
            { type: 'Bottom', description: 'Tailored camel wide-leg trousers', color: 'Camel' },
            { type: 'Outerwear', description: 'Structured brown blazer', color: 'Cognac Brown' },
            { type: 'Shoes', description: 'Pointed-toe leather pumps', color: 'Black' },
            { type: 'Accessory', description: 'Minimalist gold watch', color: 'Gold' },
          ],
          occasion,
          season,
          style_tags: ['professional', 'classic', 'elegant', 'fall'],
        },
        'date-summer-modern': {
          outfit_name: 'Summer Evening Romance',
          description: 'An effortlessly chic outfit that balances romance with modern sophistication. Light fabrics and a flattering silhouette make this perfect for a summer date.',
          items: [
            { type: 'Dress', description: 'Midi wrap dress with floral print', color: 'Coral & White' },
            { type: 'Shoes', description: 'Strappy block heel sandals', color: 'Nude' },
            { type: 'Accessory', description: 'Delicate gold layered necklace', color: 'Gold' },
            { type: 'Bag', description: 'Small chain shoulder bag', color: 'Blush Pink' },
          ],
          occasion,
          season,
          style_tags: ['romantic', 'modern', 'feminine', 'date-night'],
        },
        'party-winter-modern': {
          outfit_name: 'Winter Night Glamour',
          description: 'Make a statement with this bold and glamorous party outfit. Rich textures and metallic accents create an unforgettable look.',
          items: [
            { type: 'Top', description: 'Sequined crop top with long sleeves', color: 'Silver' },
            { type: 'Bottom', description: 'High-waisted black velvet pants', color: 'Black' },
            { type: 'Outerwear', description: 'Faux fur cropped jacket', color: 'White' },
            { type: 'Shoes', description: 'Metallic strappy heels', color: 'Silver' },
            { type: 'Accessory', description: 'Statement crystal earrings', color: 'Crystal' },
          ],
          occasion,
          season,
          style_tags: ['glamorous', 'party', 'bold', 'winter'],
        },
      };

      const key = `${occasion}-${season}-${style}`;
      const defaultOutfit: GeneratedOutfit = {
        outfit_name: `${style.charAt(0).toUpperCase() + style.slice(1)} ${occasion.charAt(0).toUpperCase() + occasion.slice(1)} Look`,
        description: `A perfectly curated ${style} outfit ideal for ${occasion} occasions during ${season}. This ensemble combines current trends with timeless appeal.`,
        items: [
          { type: 'Top', description: `Stylish ${style} top`, color: 'Versatile Neutral' },
          { type: 'Bottom', description: `Comfortable ${style} bottom`, color: 'Classic' },
          { type: 'Shoes', description: 'Fashion-forward footwear', color: 'Coordinating' },
          { type: 'Accessory', description: 'Completing accessory', color: 'Accent' },
        ],
        occasion,
        season,
        style_tags: [style, occasion, season],
      };

      setGeneratedOutfit(outfits[key] || defaultOutfit);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
            AI Outfit Generator
          </h1>
          <p className="text-gray-600 text-lg">
            Generate personalized outfit recommendations tailored to your needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">Customize Your Look</h2>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Occasion
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {occasions.map((occ) => (
                    <button
                      key={occ.value}
                      onClick={() => setOccasion(occ.value)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        occasion === occ.value
                          ? 'border-rose-500 bg-rose-50 text-rose-700 font-semibold'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {occ.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Season
                </label>
                <div className="grid grid-cols-4 gap-3">
                  {seasons.map((s) => {
                    const Icon = s.icon;
                    return (
                      <button
                        key={s.value}
                        onClick={() => setSeason(s.value)}
                        className={`p-4 rounded-lg border-2 transition-all flex flex-col items-center ${
                          season === s.value
                            ? 'border-rose-500 bg-rose-50 text-rose-700 font-semibold'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className="w-6 h-6 mb-2" />
                        <span className="text-xs">{s.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Style Preference
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {styles.map((st) => (
                    <button
                      key={st.value}
                      onClick={() => setStyle(st.value)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        style === st.value
                          ? 'border-rose-500 bg-rose-50 text-rose-700 font-semibold'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={generateOutfit}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-rose-500 to-pink-600 text-white py-4 rounded-xl font-bold text-lg hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Generate Outfit</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            {generatedOutfit ? (
              <div>
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">
                      {generatedOutfit.outfit_name}
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      {generatedOutfit.style_tags.map((tag, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-rose-100 text-rose-700 rounded-full text-xs font-medium"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={() => onSaveOutfit(generatedOutfit)}
                    className="p-3 bg-rose-50 text-rose-600 rounded-lg hover:bg-rose-100 transition-all"
                    title="Save outfit"
                  >
                    <Save className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-gray-600 mb-6 leading-relaxed">
                  {generatedOutfit.description}
                </p>

                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-800 text-lg">Outfit Items:</h3>
                  {generatedOutfit.items.map((item, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gradient-to-r from-rose-50 to-pink-50 rounded-lg border border-rose-100"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-semibold text-rose-700">{item.type}</span>
                          <p className="text-gray-700 mt-1">{item.description}</p>
                        </div>
                        <span className="px-3 py-1 bg-white rounded-full text-sm font-medium text-gray-700 border border-rose-200">
                          {item.color}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-center">
                <div>
                  <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-400 text-lg">
                    Select your preferences and generate your perfect outfit
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
