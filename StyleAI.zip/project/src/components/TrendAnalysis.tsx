import { useState, useEffect } from 'react';
import { TrendingUp, Sparkles, Filter } from 'lucide-react';
import { supabase, FashionTrend } from '../lib/supabase';

export default function TrendAnalysis() {
  const [trends, setTrends] = useState<FashionTrend[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSeason, setSelectedSeason] = useState('all');

  const categories = [
    { value: 'all', label: 'All Trends' },
    { value: 'colors', label: 'Colors' },
    { value: 'style', label: 'Styles' },
    { value: 'materials', label: 'Materials' },
    { value: 'bottoms', label: 'Bottoms' },
    { value: 'outerwear', label: 'Outerwear' },
    { value: 'lifestyle', label: 'Lifestyle' },
  ];

  const seasons = [
    { value: 'all', label: 'All Seasons' },
    { value: 'spring', label: 'Spring' },
    { value: 'summer', label: 'Summer' },
    { value: 'fall', label: 'Fall' },
    { value: 'winter', label: 'Winter' },
    { value: 'all-seasons', label: 'Year-Round' },
  ];

  useEffect(() => {
    fetchTrends();
  }, []);

  const fetchTrends = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('fashion_trends')
      .select('*')
      .order('popularity_score', { ascending: false });

    if (error) {
      console.error('Error fetching trends:', error);
    } else {
      setTrends(data || []);
    }
    setLoading(false);
  };

  const filteredTrends = trends.filter((trend) => {
    const categoryMatch = selectedCategory === 'all' || trend.category === selectedCategory;
    const seasonMatch = selectedSeason === 'all' || trend.season === selectedSeason;
    return categoryMatch && seasonMatch;
  });

  const getPopularityColor = (score: number) => {
    if (score >= 90) return 'from-rose-500 to-pink-500';
    if (score >= 80) return 'from-orange-500 to-rose-500';
    if (score >= 70) return 'from-yellow-500 to-orange-500';
    return 'from-blue-500 to-cyan-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
            Fashion Trend Analysis
          </h1>
          <p className="text-gray-600 text-lg">
            Stay ahead of the curve with real-time fashion insights
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6 mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Filter className="w-5 h-5 text-rose-500" />
            <h2 className="text-lg font-semibold text-gray-800">Filter Trends</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-rose-500 focus:outline-none"
              >
                {categories.map((cat) => (
                  <option key={cat.value} value={cat.value}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Season</label>
              <select
                value={selectedSeason}
                onChange={(e) => setSelectedSeason(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-rose-500 focus:outline-none"
              >
                {seasons.map((season) => (
                  <option key={season.value} value={season.value}>
                    {season.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-rose-500 border-t-transparent"></div>
            <p className="mt-4 text-gray-600">Loading trends...</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrends.map((trend) => (
              <div
                key={trend.id}
                className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group"
              >
                <div className={`h-2 bg-gradient-to-r ${getPopularityColor(trend.popularity_score)}`} />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-gray-800 group-hover:text-rose-600 transition-colors">
                      {trend.trend_name}
                    </h3>
                    <div className="flex items-center space-x-1">
                      <TrendingUp className="w-4 h-4 text-rose-500" />
                      <span className="text-sm font-bold text-rose-600">
                        {trend.popularity_score}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="px-3 py-1 bg-rose-100 text-rose-700 rounded-full text-xs font-medium capitalize">
                      {trend.category}
                    </span>
                    <span className="px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-xs font-medium capitalize">
                      {trend.season}
                    </span>
                  </div>

                  <p className="text-gray-600 leading-relaxed">{trend.description}</p>

                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">Popularity</span>
                      <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full bg-gradient-to-r ${getPopularityColor(trend.popularity_score)} transition-all`}
                          style={{ width: `${trend.popularity_score}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-700">
                        {trend.popularity_score}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && filteredTrends.length === 0 && (
          <div className="text-center py-12 bg-white rounded-2xl">
            <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No trends found matching your filters</p>
          </div>
        )}

        <div className="mt-12 bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">How to Use Trend Insights</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <div className="text-3xl font-bold mb-2">90+</div>
              <p className="text-sm opacity-90">
                Extremely Hot - These trends are everywhere. Perfect for staying current.
              </p>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">80-89</div>
              <p className="text-sm opacity-90">
                Very Popular - Widely adopted trends with staying power.
              </p>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">70-79</div>
              <p className="text-sm opacity-90">
                Rising - Emerging trends gaining momentum. Get ahead of the curve.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
