import { Sparkles, Shirt, TrendingUp, Camera, Zap, Heart } from 'lucide-react';

interface HomeProps {
  setActiveTab: (tab: string) => void;
}

export default function Home({ setActiveTab }: HomeProps) {
  const features = [
    {
      icon: Shirt,
      title: 'AI Outfit Generator',
      description: 'Get personalized outfit recommendations based on occasion, weather, and your style preferences.',
      color: 'from-rose-500 to-pink-500',
      tab: 'outfits',
    },
    {
      icon: Heart,
      title: 'Personal Style Advisor',
      description: 'Discover your unique style profile and receive tailored fashion advice from our AI stylist.',
      color: 'from-pink-500 to-fuchsia-500',
      tab: 'advisor',
    },
    {
      icon: TrendingUp,
      title: 'Trend Analysis',
      description: 'Stay ahead with real-time fashion trend insights and seasonal style recommendations.',
      color: 'from-fuchsia-500 to-purple-500',
      tab: 'trends',
    },
    {
      icon: Camera,
      title: 'Image Analysis',
      description: 'Upload outfit photos for instant AI-powered styling feedback and improvement suggestions.',
      color: 'from-purple-500 to-indigo-500',
      tab: 'analysis',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Sparkles className="w-20 h-20 text-rose-500 animate-pulse" />
              <Zap className="w-8 h-8 text-pink-500 absolute -top-2 -right-2" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-rose-600 via-pink-600 to-fuchsia-600 bg-clip-text text-transparent">
            Your Personal AI Fashion Assistant
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover your perfect style with cutting-edge AI technology. Get personalized outfit recommendations,
            trend insights, and expert styling advice tailored just for you.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <button
                key={index}
                onClick={() => setActiveTab(feature.tab)}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 text-left"
              >
                <div className={`inline-flex p-4 rounded-xl bg-gradient-to-r ${feature.color} mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3 text-gray-900">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </button>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl p-12 text-center text-white shadow-2xl">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Wardrobe?</h2>
          <p className="text-lg mb-8 opacity-90">
            Start your style journey today with AI-powered fashion recommendations
          </p>
          <button
            onClick={() => setActiveTab('outfits')}
            className="bg-white text-rose-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-50 transition-all shadow-lg hover:shadow-xl hover:scale-105"
          >
            Get Started Now
          </button>
        </div>
      </div>
    </div>
  );
}
