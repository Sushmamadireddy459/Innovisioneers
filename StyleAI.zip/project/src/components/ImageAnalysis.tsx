import { useState } from 'react';
import { Camera, Upload, CheckCircle, XCircle, Sparkles } from 'lucide-react';

interface AnalysisResult {
  overall_score: number;
  strengths: string[];
  improvements: string[];
  style_match: string;
  color_harmony: number;
  recommendations: string[];
}

export default function ImageAnalysis() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setAnalysisResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeOutfit = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      const mockResults: AnalysisResult[] = [
        {
          overall_score: 85,
          strengths: [
            'Excellent color coordination with complementary tones',
            'Well-proportioned outfit with balanced silhouette',
            'Professional yet stylish aesthetic',
          ],
          improvements: [
            'Consider adding a statement accessory to elevate the look',
            'The fit could be slightly more tailored at the waist',
          ],
          style_match: 'Modern Professional',
          color_harmony: 90,
          recommendations: [
            'Add a structured blazer for more polish',
            'Try metallic accessories to add dimension',
            'Consider pointed-toe shoes for a sleeker line',
          ],
        },
        {
          overall_score: 78,
          strengths: [
            'Bold color choice shows confidence',
            'Trendy silhouette aligns with current fashion',
            'Good mix of textures and fabrics',
          ],
          improvements: [
            'Color palette could be more harmonious',
            'Proportions could be better balanced',
            'Consider simplifying accessories',
          ],
          style_match: 'Urban Streetwear',
          color_harmony: 72,
          recommendations: [
            'Try neutral tones to balance the bold pieces',
            'Add layering for more depth',
            'Choose one statement piece and keep the rest minimal',
          ],
        },
        {
          overall_score: 92,
          strengths: [
            'Impeccable fit showing attention to tailoring',
            'Sophisticated color palette with cohesive look',
            'Perfect accessories that complete the outfit',
            'Excellent seasonal appropriateness',
          ],
          improvements: [
            'Already near-perfect, maybe experiment with bolder patterns',
          ],
          style_match: 'Elegant Classic',
          color_harmony: 95,
          recommendations: [
            'This is a winning formula - save this combination',
            'Try similar silhouettes in different colors',
            'Document this for future outfit planning',
          ],
        },
      ];

      setAnalysisResult(mockResults[Math.floor(Math.random() * mockResults.length)]);
      setIsAnalyzing(false);
    }, 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Great';
    if (score >= 70) return 'Good';
    return 'Needs Work';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
            AI Image Analysis
          </h1>
          <p className="text-gray-600 text-lg">
            Upload your outfit photo for instant AI-powered styling feedback
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">Upload Your Outfit</h2>

            {!selectedImage ? (
              <label className="block cursor-pointer">
                <div className="border-4 border-dashed border-gray-300 rounded-2xl p-12 text-center hover:border-rose-300 transition-all">
                  <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2 font-medium">Click to upload an image</p>
                  <p className="text-sm text-gray-500">PNG, JPG up to 10MB</p>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            ) : (
              <div>
                <img
                  src={selectedImage}
                  alt="Selected outfit"
                  className="w-full rounded-xl mb-4 shadow-lg"
                />
                <div className="flex space-x-3">
                  <label className="flex-1 cursor-pointer">
                    <div className="p-3 border-2 border-gray-300 rounded-lg text-center hover:bg-gray-50 transition-all">
                      <Upload className="w-5 h-5 inline mr-2" />
                      <span className="font-medium text-gray-700">Change Image</span>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                  <button
                    onClick={analyzeOutfit}
                    disabled={isAnalyzing}
                    className="flex-1 bg-gradient-to-r from-rose-500 to-pink-600 text-white p-3 rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        <span>Analyze</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            {analysisResult ? (
              <div>
                <div className="text-center mb-8 pb-8 border-b border-gray-100">
                  <div className={`text-6xl font-bold mb-2 ${getScoreColor(analysisResult.overall_score)}`}>
                    {analysisResult.overall_score}
                  </div>
                  <div className="text-xl font-semibold text-gray-800 mb-2">
                    {getScoreLabel(analysisResult.overall_score)} Outfit
                  </div>
                  <span className="px-4 py-2 bg-rose-100 text-rose-700 rounded-full text-sm font-medium">
                    {analysisResult.style_match}
                  </span>
                </div>

                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-700">Color Harmony</span>
                    <span className={`font-bold ${getScoreColor(analysisResult.color_harmony)}`}>
                      {analysisResult.color_harmony}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-rose-500 to-pink-500 transition-all"
                      style={{ width: `${analysisResult.color_harmony}%` }}
                    />
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                    What's Working
                  </h3>
                  <div className="space-y-2">
                    {analysisResult.strengths.map((strength, index) => (
                      <div key={index} className="p-3 bg-green-50 rounded-lg text-sm text-gray-700">
                        {strength}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                    <XCircle className="w-5 h-5 text-orange-500 mr-2" />
                    Room for Improvement
                  </h3>
                  <div className="space-y-2">
                    {analysisResult.improvements.map((improvement, index) => (
                      <div key={index} className="p-3 bg-orange-50 rounded-lg text-sm text-gray-700">
                        {improvement}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                    <Sparkles className="w-5 h-5 text-rose-500 mr-2" />
                    Style Recommendations
                  </h3>
                  <div className="space-y-2">
                    {analysisResult.recommendations.map((rec, index) => (
                      <div key={index} className="p-3 bg-rose-50 rounded-lg text-sm text-gray-700">
                        {rec}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-center">
                <div>
                  <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-400 text-lg">
                    Upload an outfit photo to get AI-powered styling feedback
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-12 bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Tips for Best Results</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold mb-2">Good Lighting</h3>
              <p className="text-sm opacity-90">
                Natural daylight or well-lit indoor spaces produce the most accurate analysis
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-2">Full Outfit Visible</h3>
              <p className="text-sm opacity-90">
                Capture the complete outfit from head to toe for comprehensive feedback
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-2">Clear Background</h3>
              <p className="text-sm opacity-90">
                Simple backgrounds help the AI focus on analyzing your outfit details
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
