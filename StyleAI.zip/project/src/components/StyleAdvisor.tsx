import { useState } from 'react';
import { Heart, Palette, ShoppingBag, User, Sparkles } from 'lucide-react';

interface StyleProfile {
  bodyType: string;
  colorPreferences: string[];
  stylePreference: string;
  budget: string;
  occasions: string[];
}

export default function StyleAdvisor() {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<StyleProfile>({
    bodyType: '',
    colorPreferences: [],
    stylePreference: '',
    budget: '',
    occasions: [],
  });
  const [showResults, setShowResults] = useState(false);

  const bodyTypes = [
    { value: 'rectangle', label: 'Rectangle', desc: 'Balanced shoulders and hips' },
    { value: 'triangle', label: 'Triangle', desc: 'Wider hips than shoulders' },
    { value: 'inverted', label: 'Inverted Triangle', desc: 'Wider shoulders than hips' },
    { value: 'hourglass', label: 'Hourglass', desc: 'Defined waist, balanced proportions' },
    { value: 'apple', label: 'Apple', desc: 'Fuller midsection' },
  ];

  const colors = [
    'Black', 'White', 'Navy', 'Beige', 'Gray',
    'Red', 'Pink', 'Blue', 'Green', 'Yellow',
  ];

  const stylePreferences = [
    { value: 'casual', label: 'Casual Comfort', desc: 'Relaxed, everyday wear' },
    { value: 'professional', label: 'Professional', desc: 'Office and business attire' },
    { value: 'elegant', label: 'Elegant Chic', desc: 'Sophisticated and refined' },
    { value: 'streetwear', label: 'Urban Streetwear', desc: 'Trendy and edgy' },
    { value: 'bohemian', label: 'Bohemian', desc: 'Free-spirited and artistic' },
    { value: 'minimalist', label: 'Minimalist', desc: 'Clean and simple lines' },
  ];

  const budgetOptions = [
    { value: 'budget', label: 'Budget-Friendly', desc: 'Under $50 per item' },
    { value: 'mid', label: 'Mid-Range', desc: '$50-$200 per item' },
    { value: 'luxury', label: 'Luxury', desc: '$200+ per item' },
  ];

  const occasionsList = [
    'Everyday Casual', 'Work/Office', 'Date Nights',
    'Parties/Events', 'Athletic/Gym', 'Formal Events',
  ];

  const toggleColor = (color: string) => {
    setProfile((prev) => ({
      ...prev,
      colorPreferences: prev.colorPreferences.includes(color)
        ? prev.colorPreferences.filter((c) => c !== color)
        : [...prev.colorPreferences, color],
    }));
  };

  const toggleOccasion = (occasion: string) => {
    setProfile((prev) => ({
      ...prev,
      occasions: prev.occasions.includes(occasion)
        ? prev.occasions.filter((o) => o !== occasion)
        : [...prev.occasions, occasion],
    }));
  };

  const generateAdvice = () => {
    setShowResults(true);
  };

  const getStyleAdvice = () => {
    const advice = {
      casualComfort: {
        title: 'Casual Comfort Master',
        description: 'Your relaxed style is all about feeling good while looking effortlessly put together.',
        tips: [
          'Invest in high-quality basics like well-fitted jeans and versatile tees',
          'Layer with denim jackets, cardigans, or casual blazers',
          'Comfortable sneakers and loafers are your best friends',
          'Add personality with accessories like scarves and simple jewelry',
        ],
      },
      professional: {
        title: 'Professional Powerhouse',
        description: 'Your polished aesthetic commands respect while showcasing your personal style.',
        tips: [
          'Build a capsule wardrobe with tailored blazers and trousers',
          'Stick to a neutral color palette with pops of color in accessories',
          'Invest in quality leather shoes and a structured work bag',
          'Silk blouses and crisp button-downs are essential staples',
        ],
      },
      elegant: {
        title: 'Elegant Sophisticate',
        description: 'Your refined taste gravitates toward timeless pieces with impeccable quality.',
        tips: [
          'Choose classic silhouettes in luxe fabrics like silk and cashmere',
          'Monochromatic outfits create an instantly polished look',
          'Statement jewelry elevates even the simplest outfit',
          'Focus on fit and tailoring for a truly elegant appearance',
        ],
      },
    };

    return advice[profile.stylePreference as keyof typeof advice] || advice.casualComfort;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {!showResults ? (
          <>
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
                Personal Style Advisor
              </h1>
              <p className="text-gray-600 text-lg">
                Discover your unique style profile in {5} simple steps
              </p>
              <div className="flex justify-center mt-6 space-x-2">
                {[1, 2, 3, 4, 5].map((s) => (
                  <div
                    key={s}
                    className={`h-2 w-12 rounded-full transition-all ${
                      s <= step ? 'bg-rose-500' : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              {step === 1 && (
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <User className="w-8 h-8 text-rose-500" />
                    <h2 className="text-2xl font-bold text-gray-800">What's your body type?</h2>
                  </div>
                  <div className="grid gap-4">
                    {bodyTypes.map((type) => (
                      <button
                        key={type.value}
                        onClick={() => setProfile({ ...profile, bodyType: type.value })}
                        className={`p-4 rounded-lg border-2 text-left transition-all ${
                          profile.bodyType === type.value
                            ? 'border-rose-500 bg-rose-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="font-semibold text-gray-800">{type.label}</div>
                        <div className="text-sm text-gray-600">{type.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {step === 2 && (
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <Palette className="w-8 h-8 text-rose-500" />
                    <h2 className="text-2xl font-bold text-gray-800">
                      What colors do you love? (Select multiple)
                    </h2>
                  </div>
                  <div className="grid grid-cols-5 gap-3">
                    {colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => toggleColor(color)}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          profile.colorPreferences.includes(color)
                            ? 'border-rose-500 bg-rose-50 font-semibold'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {step === 3 && (
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <Heart className="w-8 h-8 text-rose-500" />
                    <h2 className="text-2xl font-bold text-gray-800">What's your style vibe?</h2>
                  </div>
                  <div className="grid gap-4">
                    {stylePreferences.map((style) => (
                      <button
                        key={style.value}
                        onClick={() => setProfile({ ...profile, stylePreference: style.value })}
                        className={`p-4 rounded-lg border-2 text-left transition-all ${
                          profile.stylePreference === style.value
                            ? 'border-rose-500 bg-rose-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="font-semibold text-gray-800">{style.label}</div>
                        <div className="text-sm text-gray-600">{style.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {step === 4 && (
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <ShoppingBag className="w-8 h-8 text-rose-500" />
                    <h2 className="text-2xl font-bold text-gray-800">What's your budget range?</h2>
                  </div>
                  <div className="grid gap-4">
                    {budgetOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setProfile({ ...profile, budget: option.value })}
                        className={`p-4 rounded-lg border-2 text-left transition-all ${
                          profile.budget === option.value
                            ? 'border-rose-500 bg-rose-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="font-semibold text-gray-800">{option.label}</div>
                        <div className="text-sm text-gray-600">{option.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {step === 5 && (
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <Sparkles className="w-8 h-8 text-rose-500" />
                    <h2 className="text-2xl font-bold text-gray-800">
                      What occasions do you dress for? (Select multiple)
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {occasionsList.map((occasion) => (
                      <button
                        key={occasion}
                        onClick={() => toggleOccasion(occasion)}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          profile.occasions.includes(occasion)
                            ? 'border-rose-500 bg-rose-50 font-semibold'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        {occasion}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-between mt-8">
                <button
                  onClick={() => setStep(Math.max(1, step - 1))}
                  disabled={step === 1}
                  className="px-6 py-3 border-2 border-gray-300 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  Previous
                </button>
                {step < 5 ? (
                  <button
                    onClick={() => setStep(step + 1)}
                    className="px-6 py-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
                  >
                    Next
                  </button>
                ) : (
                  <button
                    onClick={generateAdvice}
                    className="px-6 py-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
                  >
                    Get My Style Profile
                  </button>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="inline-flex p-4 bg-gradient-to-r from-rose-500 to-pink-600 rounded-full mb-4">
                <Sparkles className="w-12 h-12 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-2">
                {getStyleAdvice().title}
              </h2>
              <p className="text-gray-600 text-lg">{getStyleAdvice().description}</p>
            </div>

            <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-xl p-6 mb-8">
              <h3 className="font-bold text-gray-800 text-xl mb-4">Your Style Profile:</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <span className="text-sm font-semibold text-gray-600">Body Type:</span>
                  <p className="text-gray-800 capitalize">{profile.bodyType}</p>
                </div>
                <div>
                  <span className="text-sm font-semibold text-gray-600">Budget:</span>
                  <p className="text-gray-800 capitalize">{profile.budget}</p>
                </div>
                <div>
                  <span className="text-sm font-semibold text-gray-600">Style Preference:</span>
                  <p className="text-gray-800 capitalize">{profile.stylePreference}</p>
                </div>
                <div>
                  <span className="text-sm font-semibold text-gray-600">Favorite Colors:</span>
                  <p className="text-gray-800">{profile.colorPreferences.join(', ')}</p>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="font-bold text-gray-800 text-xl mb-4">Personalized Style Tips:</h3>
              <div className="space-y-3">
                {getStyleAdvice().tips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-rose-50 rounded-lg">
                    <div className="flex-shrink-0 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center text-sm font-bold mt-0.5">
                      {index + 1}
                    </div>
                    <p className="text-gray-700">{tip}</p>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setShowResults(false);
                setStep(1);
              }}
              className="w-full py-4 border-2 border-rose-500 text-rose-600 rounded-xl font-bold hover:bg-rose-50 transition-all"
            >
              Retake Quiz
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
