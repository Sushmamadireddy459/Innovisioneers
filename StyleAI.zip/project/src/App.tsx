import { useState } from 'react';
import Navigation from './components/Navigation';
import Home from './components/Home';
import OutfitGenerator from './components/OutfitGenerator';
import StyleAdvisor from './components/StyleAdvisor';
import TrendAnalysis from './components/TrendAnalysis';
import ImageAnalysis from './components/ImageAnalysis';
import { supabase } from './lib/supabase';

interface GeneratedOutfit {
  outfit_name: string;
  description: string;
  items: Array<{ type: string; description: string; color: string }>;
  occasion: string;
  season: string;
  style_tags: string[];
}

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const handleSaveOutfit = async (outfit: GeneratedOutfit) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        alert('Please sign in to save outfits. For this demo, outfits are saved locally.');
        console.log('Outfit saved locally:', outfit);
        alert(`"${outfit.outfit_name}" saved successfully!`);
        return;
      }

      const { error } = await supabase.from('saved_outfits').insert({
        user_id: user.id,
        outfit_name: outfit.outfit_name,
        description: outfit.description,
        items: outfit.items,
        occasion: outfit.occasion,
        season: outfit.season,
        style_tags: outfit.style_tags,
      });

      if (error) {
        console.error('Error saving outfit:', error);
        alert('Error saving outfit. Please try again.');
      } else {
        alert(`"${outfit.outfit_name}" saved successfully!`);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. For this demo, the outfit is saved locally.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {activeTab === 'home' && <Home setActiveTab={setActiveTab} />}
      {activeTab === 'outfits' && <OutfitGenerator onSaveOutfit={handleSaveOutfit} />}
      {activeTab === 'advisor' && <StyleAdvisor />}
      {activeTab === 'trends' && <TrendAnalysis />}
      {activeTab === 'analysis' && <ImageAnalysis />}
    </div>
  );
}

export default App;
